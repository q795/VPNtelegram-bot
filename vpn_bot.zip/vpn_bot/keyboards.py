"""
Клавиатуры бота
"""
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import TARIFFS, DEMO_SERVERS


def get_main_menu() -> InlineKeyboardMarkup:
    """Главное меню"""
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="🎁 Активировать пробный период", callback_data="trial")
    )

    builder.row(
        InlineKeyboardButton(text="🛡 Подключить VPN", callback_data="get_vpn")
    )

    builder.row(
        InlineKeyboardButton(text="🔐 Мои ключи", callback_data="download_config"),
        InlineKeyboardButton(text="👤 Мой профиль", callback_data="profile")
    )

    builder.row(
        InlineKeyboardButton(text="💬 Поддержка", callback_data="support")
    )

    return builder.as_markup()


def get_profile_keyboard(has_subscription: bool, is_trial: bool = False, trial_used: bool = False) -> InlineKeyboardMarkup:
    """Клавиатура профиля"""
    builder = InlineKeyboardBuilder()

    if has_subscription:
        if not is_trial:
            builder.row(
                InlineKeyboardButton(text="💎 Продлить подписку", callback_data="renew")
            )
    else:
        if not trial_used:
            builder.row(
                InlineKeyboardButton(text="🎁 Получить пробный период", callback_data="trial")
            )
        builder.row(
            InlineKeyboardButton(text="💳 Купить подписку", callback_data="tariffs")
        )

    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")
    )

    return builder.as_markup()


def get_tariffs_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура тарифов"""
    builder = InlineKeyboardBuilder()

    for tariff in TARIFFS:
        price_text = f"{tariff['price']}₽"
        if tariff.get("discount"):
            price_text += f" (-{tariff['discount']}%)"

        builder.row(
            InlineKeyboardButton(
                text=f"{tariff['name']} — {price_text}",
                callback_data=f"buy_{tariff['id']}"
            )
        )

    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")
    )

    return builder.as_markup()


def get_servers_keyboard(selected_server: int = None) -> InlineKeyboardMarkup:
    """Клавиатура выбора сервера"""
    builder = InlineKeyboardBuilder()

    for server in DEMO_SERVERS:
        marker = "✅ " if server["id"] == selected_server else ""
        builder.row(
            InlineKeyboardButton(
                text=f"{marker}{server['name']}",
                callback_data=f"server_{server['id']}"
            )
        )

    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")
    )

    return builder.as_markup()


def get_back_keyboard() -> InlineKeyboardMarkup:
    """Кнопка назад"""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")
    )
    return builder.as_markup()


def get_confirm_trial_keyboard() -> InlineKeyboardMarkup:
    """Подтверждение пробного периода"""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Да, получить", callback_data="confirm_trial"),
        InlineKeyboardButton(text="❌ Нет", callback_data="back_to_menu")
    )
    return builder.as_markup()


def get_demo_payment_keyboard(payment_id: str) -> InlineKeyboardMarkup:
    """Демо-кнопка оплаты"""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Подтвердить оплату (Демо)",
            callback_data=f"demo_pay_{payment_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Отмена", callback_data="back_to_menu")
    )
    return builder.as_markup()